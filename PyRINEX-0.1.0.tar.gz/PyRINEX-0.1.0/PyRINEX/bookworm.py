import re
import codecs
import os
import chardet

def detectCode(path):
	with open(path, "rb") as file:
		data = file.read(200000)
		dicts = chardet.detect(data)
	return dicts["encoding"]
def show_files(path, all_files):

    # 首先遍历当前目录所有文件及文件夹
    file_list = os.listdir(path)
    # 准备循环判断每个元素是否是文件夹还是文件，是文件的话，把名称传入list，是文件夹的话，递归
    for file in file_list:
        # 利用os.path.join()方法取得路径全名，并存入cur_path变量，否则每次只能遍历一层目录
        cur_path = os.path.join(path, file)
        # 判断是否是文件夹
        if os.path.isdir(cur_path):
            show_files(cur_path, all_files)
        else:
            all_files.append(cur_path)
    return all_files

def readtxt(path):
    try:
        with open(path, "r") as file_object:
            lines = file_object.readlines()
            return lines
    except UnicodeDecodeError:
        with open(path, "r", encoding=detectCode(path)) as file_object:
            lines = file_object.readlines()
            return lines



def readtxt_in_encoding(path, ec):
    with open(path, "r", encoding=ec) as file_object:

        lines = file_object.readlines()
        return lines



def file_name_directory_detail(file_dir):
    for root, dirs, files in os.walk(file_dir):
        print(root) #当前目录路径
        print(dirs) #当前路径下所有子目录
        print(files) #当前路径下所有非目录子文件


def file_name_extesion_judgement(file_dir, extension_name):
    file_list_withdir = []

    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1] == extension_name.upper() or \
                    os.path.splitext(file)[1] == extension_name.lower():
                file_list_withdir.append(os.path.join(root, file))
        return file_list_withdir

def file_name_extesion_judgement_file(file_dir, extension_name):
    file_list = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1] == extension_name.upper() or \
                    os.path.splitext(file)[1] == extension_name.lower():
                file_list.append(file)
        return file_list


def listdir(path, list_name):  #传入存储的list
    for file in os.listdir(path):
        file_path = os.path.join(path, file)
        if os.path.isdir(file_path):
            listdir(file_path, list_name)
        else:
            list_name.append(file_path)